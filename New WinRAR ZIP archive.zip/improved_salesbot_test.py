"""
Improved AI Sales Assistant Test - Fixes search and context issues
"""

import os
import requests
import json
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.schema import Document

# Configuration
LMSTUDIO_BASE_URL = "http://localhost:1234/v1"
DATABASE_PATH = "./chroma_db_20250711_030207"

def initialize_vector_store():
    """Initialize the vector database"""
    print("🔄 Initializing vector store...")
    
    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        model_kwargs={'device': 'cpu'}
    )
    
    vectorstore = Chroma(
        persist_directory=DATABASE_PATH,
        embedding_function=embeddings
    )
    
    print(f"✅ Vector store loaded from: {DATABASE_PATH}")
    return vectorstore

def query_lmstudio(prompt, max_tokens=300):
    """Send query to LM Studio with better error handling"""
    try:
        headers = {"Content-Type": "application/json"}
        
        data = {
            "model": "qwen2.5-72b-instruct",
            "messages": [
                {
                    "role": "system",
                    "content": "You are a helpful AI Sales Assistant. Answer questions about inventory data clearly and concisely."
                },
                {
                    "role": "user", 
                    "content": prompt
                }
            ],
            "max_tokens": max_tokens,
            "temperature": 0.1,
            "stream": False
        }
        
        response = requests.post(
            f"{LMSTUDIO_BASE_URL}/chat/completions",
            headers=headers,
            json=data,
            timeout=60  # Increased timeout
        )
        
        if response.status_code == 200:
            result = response.json()
            return result["choices"][0]["message"]["content"]
        else:
            return f"Error: {response.status_code} - {response.text}"
            
    except requests.exceptions.Timeout:
        return "Error: Request timed out. Try with a shorter prompt."
    except Exception as e:
        return f"Error: {str(e)}"

def search_documents_by_sku(vectorstore, sku):
    """Search for documents containing specific SKU"""
    print(f"🔍 Searching for SKU: {sku}")
    
    # Try different search strategies
    search_terms = [
        f"SKU: {sku}",
        f"SKU {sku}",
        str(sku),
        f"{sku}.0"  # In case of decimal formatting
    ]
    
    all_docs = []
    for term in search_terms:
        docs = vectorstore.similarity_search(term, k=5)
        all_docs.extend(docs)
    
    # Remove duplicates and filter for exact SKU matches
    unique_docs = []
    seen_content = set()
    
    for doc in all_docs:
        if doc.page_content not in seen_content:
            # Check if this document actually contains the SKU
            if str(sku) in doc.page_content or f"{sku}.0" in doc.page_content:
                unique_docs.append(doc)
                seen_content.add(doc.page_content)
    
    print(f"✅ Found {len(unique_docs)} documents containing SKU {sku}")
    return unique_docs

def debug_search_results(vectorstore, query, top_k=5):
    """Debug search results to see what's being found"""
    print(f"\n🔍 DEBUG: Searching for '{query}'")
    docs = vectorstore.similarity_search(query, k=top_k)
    
    print(f"📋 Found {len(docs)} documents:")
    for i, doc in enumerate(docs):
        print(f"\n--- Document {i+1} ---")
        print(doc.page_content[:200] + "..." if len(doc.page_content) > 200 else doc.page_content)
        print(f"Metadata: {doc.metadata}")
    
    return docs

def create_concise_prompt(docs, question):
    """Create a concise prompt that fits in context window"""
    # Extract key information from documents
    info_lines = []
    for doc in docs[:2]:  # Only use top 2 documents to save space
        lines = doc.page_content.strip().split('\n')
        # Keep only the most important lines
        key_lines = [line for line in lines if any(keyword in line.lower() for keyword in ['sku:', 'product:', 'stock:', 'wac:', 'supplier:', 'lot:', 'cost:'])]
        info_lines.extend(key_lines[:8])  # Max 8 lines per document
    
    context = '\n'.join(info_lines[:15])  # Max 15 lines total
    
    prompt = f"""Based on this inventory data, answer the question:

DATA:
{context}

QUESTION: {question}

Answer briefly and specifically:"""
    
    return prompt

def test_specific_sku(vectorstore, sku):
    """Test queries for a specific SKU"""
    print(f"\n🎯 Testing SKU: {sku}")
    print("=" * 40)
    
    # Search for the SKU
    docs = search_documents_by_sku(vectorstore, sku)
    
    if not docs:
        print(f"❌ No documents found for SKU {sku}")
        return
    
    # Show what we found
    print(f"\n📋 Found data for SKU {sku}:")
    for doc in docs[:1]:  # Show first match
        print(doc.page_content)
    
    # Test specific questions
    questions = [
        f"What is the stock quantity of SKU {sku}?",
        f"What is the WAC of SKU {sku}?",
        f"Who is the supplier for SKU {sku}?",
        f"What is the product name for SKU {sku}?"
    ]
    
    for question in questions:
        print(f"\n❓ {question}")
        prompt = create_concise_prompt(docs, question)
        
        print(f"🤖 Asking LM Studio...")
        answer = query_lmstudio(prompt, max_tokens=150)
        print(f"💬 Answer: {answer}")

def browse_inventory(vectorstore):
    """Browse available inventory to see what SKUs we have"""
    print("\n📊 Browsing available inventory...")
    
    # Get some sample documents
    docs = vectorstore.similarity_search("SKU", k=10)
    
    print(f"📋 Found {len(docs)} sample documents:")
    skus_found = []
    
    for i, doc in enumerate(docs):
        lines = doc.page_content.split('\n')
        for line in lines:
            if line.startswith('SKU:'):
                sku = line.replace('SKU:', '').strip()
                if sku not in skus_found:
                    skus_found.append(sku)
                    print(f"  • SKU: {sku}")
                break
        
        if len(skus_found) >= 10:  # Show first 10 SKUs
            break
    
    return skus_found

def main():
    """Main function"""
    print("🚀 Improved AI Sales Assistant Test")
    print("=" * 50)
    
    # Initialize vector store
    vectorstore = initialize_vector_store()
    
    # Browse available inventory
    available_skus = browse_inventory(vectorstore)
    
    if not available_skus:
        print("❌ No SKUs found in database")
        return
    
    # Test with the first available SKU
    test_sku = available_skus[0]
    print(f"\n🎯 Testing with available SKU: {test_sku}")
    test_specific_sku(vectorstore, test_sku)
    
    # Test with SKU 10000010 specifically
    print(f"\n🎯 Testing with SKU 10000010 (from ingestion logs)")
    test_specific_sku(vectorstore, "10000010")
    
    # Debug search for SKU 10000010
    print(f"\n🔍 Debug search for '10000010':")
    debug_search_results(vectorstore, "10000010", top_k=3)
    
    # Interactive mode
    print(f"\n💬 Interactive mode - Available SKUs to try:")
    for sku in available_skus[:5]:
        print(f"  • {sku}")
    
    while True:
        try:
            question = input("\n💬 Your question (or 'quit'): ").strip()
            
            if question.lower() in ['quit', 'exit', 'q']:
                print("👋 Goodbye!")
                break
                
            if not question:
                continue
            
            # Simple search
            docs = vectorstore.similarity_search(question, k=3)
            if docs:
                prompt = create_concise_prompt(docs, question)
                answer = query_lmstudio(prompt, max_tokens=200)
                print(f"🤖 Answer: {answer}")
            else:
                print("❌ No relevant documents found")
                
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break

if __name__ == "__main__":
    main()